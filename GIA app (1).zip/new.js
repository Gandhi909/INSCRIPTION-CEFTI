// Création du canvas
var canvas = document.createElement("canvas");
canvas.width = 640;
canvas.height = 480;
document.body.appendChild(canvas);

// Contexte 2D
var ctx = canvas.getContext("2d");

// Personnage
var player = {
  x: 100,
  y: 100,
  width: 50,
  height: 50,
  speed: 5
};

// Ennemis
var enemies = [
  { x: 200, y: 200, width: 50, height: 50 },
  { x: 400, y: 300, width: 50, height: 50 }
];

// Boucle de jeu
function update() {
  // Effacement du canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Déplacement du personnage
  if (keys["ArrowUp"]) {
    player.y -= player.speed;
  }
  if (keys["ArrowDown"]) {
    player.y += player.speed;
  }
  if (keys["ArrowLeft"]) {
    player.x -= player.speed;
  }
  if (keys["ArrowRight"]) {
    player.x += player.speed;
  }

  // Dessin du personnage
  ctx.fillStyle = "blue";
  ctx.fillRect(player.x, player.y, player.width, player.height);

  // Dessin des ennemis
  ctx.fillStyle = "red";
  for (var i = 0; i < enemies.length; i++) {
    ctx.fillRect(enemies[i].x, enemies[i].y, enemies[i].width, enemies[i].height);
  }

  // Collision avec les ennemis
  for (var i = 0; i < enemies.length; i++) {
    if (
      player.x + player.width > enemies[i].x &&
      player.x < enemies[i].x + enemies[i].width &&
      player.y + player.height > enemies[i].y &&
      player.y < enemies[i].y + enemies[i].height
    ) {
      alert("Game Over");
    }
  }

  // Appel de la fonction update à chaque frame
  requestAnimationFrame(update);
}

// Gestion des touches
var keys = {};
document.addEventListener("keydown", function(event) {
  keys[event.key] = true;
});
document.addEventListener("keyup", function(event) {
  keys[event.key] = false;
});

// Lancement de la boucle de jeu
update();